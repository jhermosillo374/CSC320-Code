import java.util.ArrayList;
import java.util.Scanner;

public class DailyAverageTemperatures {
    public static void main(String[] args) {
        //Create an array list for days and the temperature
        ArrayList<String> days = new ArrayList<>();
        ArrayList<Double> temperatures = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        //Initializing the days of the week
        days.add("Monday");
        days.add("Tuesday");
        days.add("Wednesday");
        days.add("Thursday");
        days.add("Friday");
        days.add("Saturday");
        days.add("Sunday");
         
        //input the temperatures for each day
        for (int i = 0; i < days.size(); i++) {
            System.out.print("Enter the average temperature for " + days.get(i) + ": ");
            temperatures.add(scanner.nextDouble());
        }
            //Create a while condition that will prompt the user to input a day of the week or exit the program
        while (true) {
            System.out.print("Enter a day of the week or 'week' to see the weekly average (or 'exit' to quit): ");
            String input = scanner.next();
            //condition statements for exit and week
            if (input.equalsIgnoreCase("exit")) {
                break;
            } else if (input.equalsIgnoreCase("week")) {
                double total = 0;
                for (double temp : temperatures) {
                    total += temp;
                }
                //Create a statement to print out the weekly average
                double average = total / temperatures.size();
                System.out.println("Weekly Average Temperature: " + average);
            } else {
                //if statement to input the average temperature of the days index arraylist and temperature arraylist
                int index = days.indexOf(input);
                if (index != -1) {
                    System.out.println("Average temperature for " + days.get(index) + ": " + temperatures.get(index));
                } else {
                    //else statement for incorrect inputs 
                    System.out.println("Invalid day entered. Please try again.");
                }
            }
        }
        //close the program
        scanner.close();
    }
}